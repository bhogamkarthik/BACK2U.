# BACK2U — Campus Lost & Found

**Tagline:** Lost it? Find it. Get it BACK2U.

A responsive React + Vite prototype for a privacy-first campus lost-and-found workflow.

## Features in this prototype
- Home page and recent community listings
- Browse/search/filter public listings
- Report a lost or found item
- Private ownership clue field (not displayed on public cards)
- Item details and claim/return request flow
- My dashboard for reports and claim requests
- Demo admin review screen to approve/reject posts and update claim status
- Browser persistence with `localStorage`
- Responsive layout for desktop and mobile

## Run locally
Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

For a production build:

```bash
npm run build
npm run preview
```

## Important limitations
This is a **front-end demonstration**, not a production-ready system. Data is stored in the current browser only; it is not shared between users or devices. The demo admin page has no login and is not secure. Before real campus use, add campus authentication, a backend/database, server-side role-based authorization, secure private-claim handling, spam/report controls, and a supervised handover workflow. Do not enter real sensitive student information into this demo.

## Suggested next steps
1. Create a GitHub repository named `BACK2U`.
2. Upload the contents of this folder to the repository root.
3. Run the app locally and check the main workflows.
4. Add backend/authentication only after the UI and project requirements are approved.
